<?php
ob_start();
session_start();
//error_reporting( E_ALL );
$dir_path=str_replace("include","",dirname(__FILE__));

$serverip = array('127.0.0.1', "::1");
if(!in_array($_SERVER['REMOTE_ADDR'], $serverip)){
$host = "https://vikashxfriday.github.io/tours";
}else{
$host = "https://vikashxfriday.github.io/tours";
}

$host_logo=$host."/images/admin-logo.png";
$host_path=$host;
$host_company="ITIO INNOVEX";
$host_email="info@itio.in";
$host_mobile="+ 0120-4638249";
$host_address1="Test Address 111";
$host_address2="Test Address 2222";