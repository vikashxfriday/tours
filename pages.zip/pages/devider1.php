    <!-- Client Section -->
    <section class="section client-section-four wow zoomIn" data-wow-delay="0.2s">
        <div class="container">
            <div class="client-sec">
                <div class="section-header text-center  wow fadeInDown">
                    <h6 class="text-white">We are working with 50+ Clients</h6>
                </div>
                <div class="owl-carousel client-slider">
                    <div class="client-img">
                        <img src="assets/img/clients/client-08.svg" alt="img">
                    </div>
                    <div class="client-img">
                        <img src="assets/img/clients/client-09.svg" alt="img">
                    </div>
                    <div class="client-img">
                        <img src="assets/img/clients/client-10.svg" alt="img">
                    </div>
                    <div class="client-img">
                        <img src="assets/img/clients/client-11.svg" alt="img">
                    </div>
                    <div class="client-img">
                        <img src="assets/img/clients/client-12.svg" alt="img">
                    </div>
                    <div class="client-img">
                        <img src="assets/img/clients/client-13.svg" alt="img">
                    </div>
                    <div class="client-img">
                        <img src="assets/img/clients/client-14.svg" alt="img">
                    </div>
                    <div class="client-img">
                        <img src="assets/img/clients/client-10.svg" alt="img">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /Client Section -->